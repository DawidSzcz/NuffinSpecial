#ifndef CONTROLS_HPP
#define CONTROLS_HPP

void computeMatricesFromInputs();
glm::mat4 getCameraPos();
bool is3d();
GLfloat getYCord();

#endif
