
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <IL/il.h>
#include <IL/ilu.h>
#include <IL/ilut.h>

#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>

#include "shader.hpp"
static GLFWwindow* window;
static std::vector < GLfloat > *data;
int makeWindow(char* str)
{        
	if( !glfwInit() )
        {
                fprintf( stderr, "Failed to initialize GLFW\n" );
                return -1;
        }

        glfwWindowHint(GLFW_SAMPLES, 4);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

        window = glfwCreateWindow( 1024, 768, str, NULL, NULL);
        if( window == NULL ){
                fprintf( stderr, "Failed to open GLFW window. If you have an Intel GPU, they are not 3.3 compatible. Try the 2.1 version of the tutorials.\n" );
                glfwTerminate();
                return -1;
        }
        glfwMakeContextCurrent(window);
        // Initialize GLEW
        glewExperimental = true; // Needed for core profile
        if (glewInit() != GLEW_OK) {
                fprintf(stderr, "Failed to initialize GLEW\n");
                return -1;
        }

        // Ensure we can capture the escape key being pressed below
        glfwSetInputMode(window, GLFW_STICKY_KEYS, GL_TRUE);

        // Dark blue background
        glClearColor(0.0f, 0.5f, 0.4f, 0.0f);
}

void resize(int args, char* path)
{
	FILE* file = fopen (path , "r");
	char wiersz[1000];
	GLfloat minX = 10000, maxX = -10000, minY = 10000, maxY = -10000, scaleX, scaleY, scaleC, moveX, moveY, x, y;
	std::cout << path<<std::endl;
	while (fgets(wiersz, 1000, file) != NULL){
		std::cout << wiersz<<std::endl;
                        if (strstr(wiersz, "MMPLL")){
                                sscanf( wiersz, "MMPLL, %*d, %f, %f", &x, &y);
				if(x > maxX) maxX = x;
				if(x < minX) minX = x;
				if(y > maxY) maxY = y;
				if(y < minY) minY = y;
                        }
	}
	std::cout << "bounds" << maxX << " " << minX <<" " << maxY << " " << minY<<std::endl;
	scaleX = (maxX - minX)/2;
        scaleY = (maxY - minY)/2;
        moveX = (maxX + minX)/2 ;
        moveY = (maxY + minY)/2;
		std::cout << "scaleX" << scaleX << " scaleY " << scaleY <<std::endl;
		for(int arg = 0; arg < args; arg++)		
				for(int i = 0; i < data[arg].size();i++)
				{
				        data[arg][i] = (data[arg][i] -moveX) / scaleX;
				        data[arg][++i] = (data[arg][i] -moveY) / scaleY;
				        i++;  
				}       
}

int loadVertex(int arg, char * argv)
{
        std::cout << arg << std::endl;
                FILE* file = fopen (argv , "r");
                char wiersz[1000];
                char latlon=0;
                std::cout << "laduje\n";
                while (fgets(wiersz, 1000, file) != NULL){
                        //std::cout << wiersz << std::endl;
                        float lat,lon,ele;
                        char *p;
                        if (strstr(wiersz, "<trkpt ")){
                                 sscanf( strstr(wiersz, "lat=\"")+5, "%f", &lat);
                                 sscanf( strstr(wiersz, "lon=\"")+5, "%f", &lon);
                                 data[arg].push_back(lat);
                                 data[arg].push_back(lon);

                                 latlon = 1;
                        }
                        else if (p=strstr(wiersz, "<ele>")){
                                 sscanf( p+5, "%f</ele>", &ele); 
                                 if (latlon == 1) {
                                            data[arg].push_back(ele);
                                 }
                        }
                }

                std::cout << "done" << std::endl;
		std::cout << data[arg].size() << std::endl;
}

int main(int argc, char * argv[] )
{
	data = new std::vector < GLfloat >[argc-3]();
	for(int i = 0; i < argc -3; i++)
        	loadVertex(i, argv[i+3]);
	resize(argc-3, argv[1]);
	std::string path = argv[2];
	if(makeWindow((char*)"Zad1") == -1)
		return -1;

	ilInit();
	ILuint ImageName;
	ilGenImages(1, &ImageName);
	ilBindImage(ImageName);
	ilEnable(IL_ORIGIN_SET);
	ilOriginFunc(IL_ORIGIN_LOWER_LEFT);
	ILboolean success = ilLoadImage((ILstring)path.c_str());
	if(success == false)
	{
		ILenum Error ;
		while ((Error = ilGetError()) != IL_NO_ERROR) 
		    fprintf(stderr, "%d\n",Error);
	}
	else
		std::cout<<"Poszlo\n";
	ILuint width = ilGetInteger(IL_IMAGE_WIDTH);
	ILuint height = ilGetInteger(IL_IMAGE_HEIGHT); 
	ILubyte *Data = ilGetData(); 
	std::cout<<width<<" "<<height<<"\n";

 	GLuint programID = LoadShaders( "SimpleTransform.vertexshader", "SimpleFragmentShader.fragmentshader" );
	GLuint texture;
	glGenTextures(1, &texture);  
	glBindTexture(GL_TEXTURE_2D, texture);  
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, Data);
	glGenerateMipmap(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, 0); 

	GLfloat vertexes[] = {
    		-0.5f, 0.5f, 0.0f, 1.0f,
     		0.5f, 0.5f, 1.0f, 1.0f,
     		-0.5f,  -0.5f, 0.0f, 0.0f,
		0.5f, -0.5f, 1.0f, 0.0f
	};  
	GLuint indices[] = {  2, 0, 1, 2, 3, 1};
        
	GLuint VAO, VBA, EBO, VAOPATH, VBAPATH;
        glGenVertexArrays(1, &VAO);
        glBindVertexArray(VAO);
	glGenBuffers(1, &VBA);
        glBindBuffer(GL_ARRAY_BUFFER,VBA);
	glBufferData(GL_ARRAY_BUFFER, 16* sizeof(GLfloat), vertexes, GL_STATIC_DRAW);
	glGenBuffers(1, &EBO);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices), indices, GL_STATIC_DRAW); 
	glVertexAttribPointer(
                    0,                  // attribute. No particular reason for 0, but must match the layout in the shader.
                    2,                  // size
                    GL_FLOAT,           // type
                    GL_FALSE,           // normalized?
                    4*sizeof(GLfloat),                  // stride
                    (void*)0            // array buffer offset
        );
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(
                    1,                  // attribute. No particular reason for 0, but must match the layout in the shader.
                    2,                  // size
                    GL_FLOAT,           // type
                    GL_FALSE,           // normalized?
                    4*sizeof(GLfloat),                  // stride
                    (void*)(2*sizeof(GLfloat))           // array buffer offset
        );
	glEnableVertexAttribArray(1);
	glBindVertexArray(0); 

	glGenVertexArrays(1, &VAOPATH);
        glBindVertexArray(VAOPATH);
	glGenBuffers(1, &VBAPATH);
        glBindBuffer(GL_ARRAY_BUFFER,VBAPATH);
	glBufferData(GL_ARRAY_BUFFER, data.size()* sizeof(GLfloat), &data[i].front(), GL_STATIC_DRAW);
	glVertexAttribPointer(
                    2,                  // attribute. No particular reason for 0, but must match the layout in the shader.
                    3,                  // size
                    GL_FLOAT,           // type
                    GL_FALSE,           // normalized?
                    data.size()*sizeof(GLfloat),                  // stride
                    (void*)0            // array buffer offset
        );
	glEnableVertexAttribArray(2);	
	glBindVertexArray(0);

	
	do{
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
		
		glUseProgram(programID);		
		glBindVertexArray(VAO);		
		glBindTexture(GL_TEXTURE_2D, texture);
                glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
		glBindVertexArray(0);

		glfwSwapBuffers(window);
		glfwPollEvents();

	} // Check if the ESC key was pressed or the window was closed
	while( glfwGetKey(window, GLFW_KEY_ESCAPE ) != GLFW_PRESS &&
		   glfwWindowShouldClose(window) == 0 );

	// Close OpenGL window and terminate GLFW
	glfwTerminate();

	return 0;

}
