bubsort(X, Y):-
	length(X, L),
	random_between(2, L, Rand),
	swap(Rand, X, New),
	(checkSorted(X),
		Y = X, !;
		bubsort(New, Y)).
		

swap(2, [H, H1|T], Y):-
	H > H1,
		Y = [H1,H|T];
		Y = [H,H1|T].	
swap(L,[H|T], [H|R]):-
	L1 is L -1,
	swap(L1, T,R).
	
 checkSorted([_]).
 checkSorted([H,H1|T]):-
 	H =< H1,
 		checkSorted([H1|T]);
 		false.
